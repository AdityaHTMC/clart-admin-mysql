

const SocialMediaIcons = () => {
  return (
    <ul className="social">
      <li>
        <a href="#javascript">
          <i className="icon-facebook"></i>
          {/* <Facebook /> */}
        </a>
      </li>
      <li>
        <a href="#javascript">
          <i className="icon-twitter-alt"></i>
        </a>
      </li>
      <li>
        <a href="#javascript">
          <i className="icon-instagram"></i>
        </a>
      </li>
      <li>
        <a href="#javascript">
          <i className="icon-pinterest-alt"></i>
        </a>
      </li>
    </ul>
  );
};

export default SocialMediaIcons;
